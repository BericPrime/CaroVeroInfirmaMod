package net.dengusprime.caroveroinfirma.worldgen.biome.surface;

import net.dengusprime.caroveroinfirma.block.ModBlocks;
import net.dengusprime.caroveroinfirma.worldgen.biome.ModBiomes;
import net.minecraft.world.level.block.Block;
import net.minecraft.world.level.block.Blocks;
import net.minecraft.world.level.levelgen.SurfaceRules;

public class ModSurfaceRules {
    private static final SurfaceRules.RuleSource BLEACHED_DIRT = makeStateRule(ModBlocks.BLEACHED_DIRT.get());
    private static final SurfaceRules.RuleSource BLEACHED_COARSE_DIRT = makeStateRule(ModBlocks.BLEACHED_COARSE_DIRT.get());
    private static final SurfaceRules.RuleSource DEAD_GRASS_BLOCK = makeStateRule(ModBlocks.DEAD_GRASS_BLOCK.get());
    private static final SurfaceRules.RuleSource GARBAGE_BLOCK = makeStateRule(ModBlocks.GARBAGE_BLOCK.get());
    private static final SurfaceRules.RuleSource GARBAGE_NODE = makeStateRule(ModBlocks.GARBAGE_NODE.get());


    public static SurfaceRules.RuleSource makeRules() {
        SurfaceRules.ConditionSource isAtOrAboveWaterLevel = SurfaceRules.waterBlockCheck(-1, 0);

        SurfaceRules.RuleSource grassSurface = SurfaceRules.sequence(SurfaceRules.ifTrue(isAtOrAboveWaterLevel, DEAD_GRASS_BLOCK), BLEACHED_DIRT);

        return SurfaceRules.sequence(
                SurfaceRules.sequence(SurfaceRules.ifTrue(SurfaceRules.isBiome(ModBiomes.INDUSTRIAL_WASTELAND),
                                SurfaceRules.ifTrue(SurfaceRules.ON_FLOOR, BLEACHED_COARSE_DIRT)),
                        SurfaceRules.ifTrue(SurfaceRules.ON_CEILING, BLEACHED_DIRT)),


                // Default to a grass and dirt surface
                SurfaceRules.ifTrue(SurfaceRules.ON_FLOOR,grassSurface)
        );
    }

    private static SurfaceRules.RuleSource makeStateRule(Block block) {
        return SurfaceRules.state(block.defaultBlockState());
    }
}